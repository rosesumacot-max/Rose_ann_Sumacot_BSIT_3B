<?php include "db.php"; ?>

<?php
$id = $_GET['id'];
$row = $conn->query("SELECT * FROM books WHERE id=$id")->fetch_assoc();

if(isset($_POST['update'])){
$conn->query("UPDATE books SET 
title='$_POST[title]',
author='$_POST[author]' 
WHERE id=$id");

header("Location: index.php");
}
?>

<form method="POST">
<input name="title" value="<?= $row['title'] ?>">
<input name="author" value="<?= $row['author'] ?>">
<button name="update">Update</button>
</form>