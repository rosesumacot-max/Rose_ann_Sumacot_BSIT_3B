<?php include "db.php"; ?>

<?php
$id = $_GET['id'];

$conn->query("UPDATE borrowed_books 
SET status='Returned', return_date=CURDATE() 
WHERE id=$id");

$conn->query("UPDATE books 
SET status='Available' 
WHERE id=(SELECT book_id FROM borrowed_books WHERE id=$id)");

header("Location: borrowed.php");
?>