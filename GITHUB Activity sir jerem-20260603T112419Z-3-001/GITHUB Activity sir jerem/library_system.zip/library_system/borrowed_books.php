<?php include "db.php"; ?>

<h2>Borrowed Books</h2>

<table border="1">
<tr>
<th>Book ID</th><th>Borrower</th><th>Borrow Date</th><th>Due Date</th><th>Status</th><th>Action</th>
</tr>

<?php
$sql = "SELECT * FROM borrowed_books";
$result = $conn->query($sql);

while($row = $result->fetch_assoc()){
$status = ($row['due_date'] < date("Y-m-d") && $row['status']=='Borrowed') 
? "Overdue" : $row['status'];

echo "<tr>
<td>{$row['book_id']}</td>
<td>{$row['borrower_name']}</td>
<td>{$row['borrow_date']}</td>
<td>{$row['due_date']}</td>
<td>$status</td>
<td>";

if($row['status']=='Borrowed'){
echo "<a href='return.php?id={$row['id']}'>Return</a>";
}

echo "</td></tr>";
}
?>

</table>