<?php include "db.php"; ?>

<?php
$id = $_GET['id'];

$conn->query("UPDATE books SET status='Borrowed' WHERE id=$id");

$conn->query("INSERT INTO borrowed_books
(book_id, borrower_name, borrow_date, due_date)
VALUES ($id, 'Student', CURDATE(), DATE_ADD(CURDATE(), INTERVAL 7 DAY))");

header("Location: index.php");
?>