<?php
$conn = new mysqli("localhost", "root", "", "library_system");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

/* ADD BOOK */
if (isset($_POST['add_book'])) {
    $title = $_POST['title'];
    $author = $_POST['author'];

    $conn->query("INSERT INTO books(title, author) VALUES('$title', '$author')");
    header("Location: index.php");
}

/* EDIT BOOK */
if (isset($_POST['update_book'])) {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $author = $_POST['author'];

    $conn->query("UPDATE books SET title='$title', author='$author' WHERE id=$id");
    header("Location: index.php");
}

/* DELETE BOOK */
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM books WHERE id=$id");
    header("Location: index.php");
}

/* BORROW BOOK */
if (isset($_POST['borrow'])) {
    $book_id = $_POST['book_id'];
    $name = $_POST['borrower_name'];

    $borrow_date = date("Y-m-d");
    $due_date = date("Y-m-d", strtotime("+7 days"));

    $conn->query("INSERT INTO borrowed_books(book_id, borrower_name, borrow_date, due_date, status)
    VALUES('$book_id', '$name', '$borrow_date', '$due_date', 'Borrowed')");

    $conn->query("UPDATE books SET status='Borrowed' WHERE id=$book_id");

    header("Location: index.php");
}

/* RETURN BOOK */
if (isset($_GET['return'])) {
    $id = $_GET['return'];

    $borrow = $conn->query("SELECT * FROM borrowed_books WHERE id=$id")->fetch_assoc();
    $book_id = $borrow['book_id'];

    $conn->query("UPDATE borrowed_books SET status='Returned', return_date=CURDATE() WHERE id=$id");
    $conn->query("UPDATE books SET status='Available' WHERE id=$book_id");

    header("Location: index.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Library System</title>

<style>
body {
    font-family: Arial;
    background: #ffd6e7;
    text-align: center;
}

.container {
    width: 90%;
    margin: auto;
    background: #fff0f5;
    padding: 20px;
    border-radius: 10px;
}

h1 {
    color: #d63384;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

th, td {
    border: 1px solid #ccc;
    padding: 10px;
}

th {
    background: #ffb6c1;
}

.btn {
    padding: 5px 10px;
    background: #d63384;
    color: white;
    text-decoration: none;
    border-radius: 5px;
}

.overdue {
    background: #ffcccc;
}

/* BUTTON STYLE */
.toggle-btn {
    background: #d63384;
    color: white;
    padding: 8px 12px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    margin-bottom: 10px;
}
</style>

<!-- JS FOR TOGGLE -->
<script>
function toggleBorrowed() {
    var x = document.getElementById("borrowedTable");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}
</script>

</head>

<body>

<div class="container">

<h1>📚 Library Dashboard</h1>

<?php
$total = $conn->query("SELECT COUNT(*) as t FROM books")->fetch_assoc()['t'];
$borrowed = $conn->query("SELECT COUNT(*) as b FROM books WHERE status='Borrowed'")->fetch_assoc()['b'];
$available = $total - $borrowed;
?>

<h3>Total Books: <?= $total ?> | Borrowed: <?= $borrowed ?> | Available: <?= $available ?></h3>

<hr>

<!-- ADD BOOK -->
<h2>➕ Add Book</h2>
<form method="POST">
    <input type="text" name="title" placeholder="Title" required>
    <input type="text" name="author" placeholder="Author" required>
    <button name="add_book">Add</button>
</form>

<!-- EDIT BOOK -->
<h2>✏️ Edit Book</h2>
<form method="POST">
    <input type="number" name="id" placeholder="Book ID" required>
    <input type="text" name="title" placeholder="New Title" required>
    <input type="text" name="author" placeholder="New Author" required>
    <button name="update_book">Update</button>
</form>

<!-- BOOK LIST -->
<h2>📖 Books</h2>

<table>
<tr>
    <th>ID</th>
    <th>Title</th>
    <th>Author</th>
    <th>Status</th>
    <th>Action</th>
</tr>

<?php
$books = $conn->query("SELECT * FROM books");
while ($row = $books->fetch_assoc()):
?>
<tr>
    <td><?= $row['id'] ?></td>
    <td><?= $row['title'] ?></td>
    <td><?= $row['author'] ?></td>
    <td><?= $row['status'] ?></td>
    <td>
        <a class="btn" href="?delete=<?= $row['id'] ?>">Delete</a>
    </td>
</tr>
<?php endwhile; ?>
</table>

<hr>

<!-- BORROW -->
<h2>📥 Borrow Book</h2>
<form method="POST">
    <select name="book_id">
        <?php
        $avail = $conn->query("SELECT * FROM books WHERE status='Available'");
        while ($b = $avail->fetch_assoc()):
        ?>
        <option value="<?= $b['id'] ?>"><?= $b['title'] ?></option>
        <?php endwhile; ?>
    </select>

    <input type="text" name="borrower_name" placeholder="Borrower Name" required>
    <button name="borrow">Borrow</button>
</form>

<hr>

<!-- TOGGLE BUTTON -->
<h2>📌 Borrowed Books</h2>
<button class="toggle-btn" onclick="toggleBorrowed()">
    Show / Hide Borrowed Books
</button>

<!-- BORROWED TABLE (HIDDEN BY DEFAULT) -->
<div id="borrowedTable" style="display:none;">

<table>
<tr>
    <th>Book</th>
    <th>Borrower</th>
    <th>Borrow Date</th>
    <th>Due Date</th>
    <th>Status</th>
    <th>Action</th>
</tr>

<?php
$sql = "SELECT borrowed_books.*, books.title 
        FROM borrowed_books 
        JOIN books ON books.id = borrowed_books.book_id";

$result = $conn->query($sql);

while ($row = $result->fetch_assoc()):

$overdue = ($row['status'] == 'Borrowed' && $row['due_date'] < date("Y-m-d"));
?>

<tr class="<?= $overdue ? 'overdue' : '' ?>">
    <td><?= $row['title'] ?></td>
    <td><?= $row['borrower_name'] ?></td>
    <td><?= $row['borrow_date'] ?></td>
    <td><?= $row['due_date'] ?></td>
    <td><?= $row['status'] ?></td>
    <td>
        <?php if ($row['status'] == 'Borrowed'): ?>
        <a class="btn" href="?return=<?= $row['id'] ?>">Return</a>
        <?php endif; ?>
    </td>
</tr>

<?php endwhile; ?>

</table>

</div>

</div>

</body>
</html>