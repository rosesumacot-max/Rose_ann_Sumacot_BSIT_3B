<?php include "db.php"; ?>

<form method="POST">
<input name="title" placeholder="Title">
<input name="author" placeholder="Author">
<button name="save">Save</button>
</form>

<?php
if(isset($_POST['save'])){
$conn->query("INSERT INTO books(title,author) 
VALUES('$_POST[title]','$_POST[author]')");
header("Location: index.php");
}
?>